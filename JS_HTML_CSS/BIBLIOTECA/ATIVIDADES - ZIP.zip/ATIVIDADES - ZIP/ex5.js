// 5. Loja de Discos Escreva um programa para representar um disco com propriedades comotítulo, artista, ano de lançamento e preço. 

function representarDisco() {
    titulo = "The Dark Side of the Moon";
    artista = "Pink Floyd";
    ano = "1973";
    preco = "R$ 50,00";

    alert("Detalhes do Disco:\n" +
          "Título: " + titulo + "\n" +
          "Artista: " + artista + "\n" +
          "Ano de Lançamento: " + ano + "\n" +
          "Preço: " + preco);
}

representarDisco();